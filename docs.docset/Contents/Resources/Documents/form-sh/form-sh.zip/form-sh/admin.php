
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Административная панель</title>
</head>
<body>
    <h2>Добавить запись</h2>
    <form action="admin_panel.php" method="post">
        <label for="title">Заголовок:</label><br>
        <input type="text" id="title" name="title"><br>
        <label for="content">Содержимое:</label><br>
        <textarea id="content" name="content"></textarea><br>
        <button type="submit" name="add">Добавить</button>
    </form>

    <h2>Редактировать запись</h2>
    <form action="admin_panel.php" method="post">
        <label for="id">ID записи:</label><br>
        <input type="text" id="id" name="id"><br>
        <label for="title">Новый заголовок:</label><br>
        <input type="text" id="title" name="title"><br>
        <label for="content">Новое содержимое:</label><br>
        <textarea id="content" name="content"></textarea><br>
        <button type="submit" name="edit">Редактировать</button>
    </form>

    <h2>Удалить запись</h2>
    <form action="admin_panel.php" method="post">
        <label for="id">ID записи:</label><br>
        <input type="text" id="id" name="id"><br>
        <button type="submit" name="delete">Удалить</button>
    </form>
</body>
</html>