<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registerUsers";

$conn = new mysqli($servername, $username, $password, $dbname);

if(isset($_POST['add'])){
    $title = $_POST['title'];
    $content = $_POST['content'];
    
    $sql = "INSERT INTO `posts` (title, content) VALUES ('$title', '$content')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Запись успешно добавлена";
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }
}

// Редактирование записи
if(isset($_POST['edit'])){
    $id = $_POST['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    
    $sql = "UPDATE `posts` SET title='$title', content='$content' WHERE id='$id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Запись успешно отредактирована";
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }
}

// Удаление записи
if(isset($_POST['delete'])){
    $id = $_POST['id'];
    
    $sql = "DELETE FROM `posts` WHERE id='$id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Запись успешно удалена";
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();