<?php
session_start();
require_once("db.php");

$login = $_POST['login'];
$pass = $_POST['pass'];

if(empty($login) || empty($pass)){
    echo "Заполните все поля!";
}
else{
    $sql = "SELECT * FROM `users` WHERE login = '$login' AND pass = '$pass'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0)
    {
        while($row = $result->fetch_assoc()){
            if($login =='admin'){
                header('Location: admin.php');
            }else{
            $_SESSION['login'] = $login;
            echo "Добро пожаловать!";
            header('Location: office.php');
            }
        }
    }
    else{
        echo "Нет такого пользователя!";
    }
}

