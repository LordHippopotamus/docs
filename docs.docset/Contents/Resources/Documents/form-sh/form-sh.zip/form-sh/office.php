<?php
session_start();
require_once("db.php");

function printResult($result){
    if($result->num_rows > 0){
        //print_r($result->fetch_all());
        while($row = $result -> fetch_assoc()){
            echo "Заголовок: " .$row['title']. '.';
            echo "Текст: " .$row['content']. '.';
        }
    }
    echo "<hr>";
}
$mysql = new mysqli("localhost", "root", "", "registerUsers");
$result =  $mysql->query("SELECT * FROM `users`");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
</head>
<body>
    <h3><?php
        if (isset($_SESSION['login'])) {
            echo 'Добро пожаловать, ' .$_SESSION['login'];
        } else {
        }

        $result =  $mysql->query("SELECT * FROM `posts`");
        printResult($result);
        ?>


</h3>
</body>
</html>

