<?php
require_once("db.php");
$login = $_POST['login'];
$pass = $_POST['pass'];
$repeatpass = $_POST['repeatpass'];
$email = $_POST['email'];

function redirect(){
    header('Location: login.php');
    exit;
}
if(empty($login) || empty($pass) || empty($repeatpass || empty($email))){
echo "Заполните все поля!";
}
else{
    if($login < 2){
        echo "Введите логин от 3 символов";
    }
    else if($pass < 5 && $pass > 16){
        echo "Пароль должен состоять от 6 до 16 символов!";
    }
    else if($pass != $repeatpass){
        echo "Пароли не совпадают!";
    }
    else if($_SERVER["REQUEST_METHOD"] == "POST"){
        $email = $_POST['email'];

        // Проверка наличия адреса электронной почты в базе данных
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = $conn->query($sql);
    
        if ($result->num_rows > 0) {
            // Адрес электронной почты уже используется
            echo "Адрес электронной почты уже используется";
        } else {
            $sql = "INSERT INTO `users` (login, pass, email) VALUES ('$login', '$pass', '$email')";

        if($conn -> query($sql) === TRUE){
            echo "Успешная регистрация!";
        }
        else{
            echo "Ошибка: " .$conn->error;
        }
        }
    }
    else{
   
    }
}


