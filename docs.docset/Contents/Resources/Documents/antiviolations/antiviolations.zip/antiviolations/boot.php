<?php
$dsn = 'mysql:dbname=antiviolations;host=127.0.0.1';
$user = 'root';
$password = '';
$pdo = new PDO($dsn, $user, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
session_start();
function flash(?string $message = null)
{
    if ($message) {
        $_SESSION['flash'] = $message;
    } else {
        if (!empty($_SESSION['flash'])) { ?>
            <p><?= $_SESSION['flash'] ?></p>
        <?php }
        unset($_SESSION['flash']);
    }
}