<?php
require './boot.php';

$applicant = $_POST['applicant'];
$registration_number = $_POST['registration_number'];
$description = $_POST['description'];

try {
    $stmt = $pdo->prepare('INSERT INTO violations (applicant, registration_number, description) VALUES (?, ?, ?)');
    $stmt->execute([$applicant, $registration_number, $description]);
} catch (PDOException $e) {
    flash($e->getMessage());
}

header('Location: /');
exit;