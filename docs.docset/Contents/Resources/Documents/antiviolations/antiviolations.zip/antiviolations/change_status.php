<?php
require './boot.php';

$id = $_POST['id'];
$status = $_POST['status'];

try {
    // $stmt = $pdo->prepare("UPDATE violations SET (status) values (?) WHERE id = ?");
    $stmt = $pdo->prepare("UPDATE violations SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
} catch (PDOException $e) {
    flash($e->getMessage());
}

header('Location: /');
exit;