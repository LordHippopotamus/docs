<?php
require '../boot.php';

$login = $_POST['login'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$email = $_POST['email'];

try {
    $stmt = $pdo->prepare('INSERT INTO users (login, password, full_name, phone, email) values (?, ?, ?, ?, ?)');
    $success = $stmt->execute([$login, $password, $full_name, $phone, $email]);
    if ($success) {
        header('Location: /login');
        exit;
    }
} catch (PDOException $e) {
    flash($e->getMessage());
    header('Location: /registration');
    exit;
}