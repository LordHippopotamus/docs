<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<?php
require '../boot.php';

if (!$user) {
    header('Location: /login.php');
    exit;
}

if ($user['role'] !== 'admin') {
    header('Location: /');
    exit;
}
?>

<style>
    table,
    tr,
    td {
        border: 1px solid black
    }

    td {
        padding: 4px;
    }
</style>

<body>
    <h1>Админ Панель</h1>
    <div>
        <h2>Список нарушений</h2>
        <table>
            <?php
            $violations = $pdo->query('SELECT * FROM violations');
            foreach ($violations as $violation) { ?>
                <tr>
                    <td><?= $violation['registration_number'] ?></td>
                    <td><?= $violation['description'] ?></td>
                    <td>
                        <form method="POST" action="change_status.php">
                            <input name="id" value="<?= $violation['id'] ?>" type="hidden" />
                            <input name="status" value="<?= $violation['status'] ?>" />
                            <button>Сохранить</button></button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <?php flash() ?>
    </div>
</body>

</html>