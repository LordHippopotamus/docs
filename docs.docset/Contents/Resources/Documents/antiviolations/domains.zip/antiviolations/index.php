<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<?php
require './boot.php';

$user = $_SESSION['user'];

if (!$user) {
    header('Location: /login.php');
    exit;
}

if ($user['role'] === 'admin') {
    header('Location: /admin.php');
    exit;
}
?>

<body>
    <div>
        <h1>Нарушениям Нет</h1>
        <p>Добро пожаловать, <?= $user['login'] ?>!</p>
    </div>

    <div>
        <h2>Добавить нарушение</h2>
        <form method="POST" action="create_violation.php">
            <input name="applicant" value="<?= $user['id'] ?>" type="hidden" />
            <input name="registration_number" placeholder="Регистрационный номер" />
            <textarea name="description" placeholder="Описание нарушения"></textarea>
            <button>Отправить</button>
        </form>
        <?php flash() ?>
    </div>

    <div>
        <h2>Список добавленных нарушений</h2>
        <?php
        $stmt = $pdo->prepare('SELECT * FROM violations WHERE applicant = ?');
        $stmt->execute([$user['id']]);
        $violations = $stmt->fetchAll();
        if ($stmt->rowCount() > 0) {
            echo '<ul>';
            foreach ($violations as $violation) { ?>
                <li>
                    <b><?= $violation['status'] ?></b>
                    <b><?= $violation['registration_number'] ?></b>
                    <p><?= $violation['description'] ?></p>
                </li>
            <?php }
            echo '</ul>';
        } else {
            echo '<p>Нет оставленных заявлений</p>';
        }
        ?>
    </div>
</body>

</html>