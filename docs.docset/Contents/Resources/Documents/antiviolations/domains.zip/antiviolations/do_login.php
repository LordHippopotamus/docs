<?php
require './boot.php';

$login = $_POST['login'];
$password = $_POST['password'];

try {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE login = ?');
    $stmt->execute([$login]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$user) {
        throw new Exception('Пользователя с таким логином не существует');
    } else {
        if (!password_verify($password, $user['password'])) {
            throw new Exception('Неверный пароль');
        } else {
            $_SESSION['user'] = $user;
            header('Location: /');
            exit;
        }
    }
} catch (Exception $e) {
    flash($e->getMessage());
    header('Location: /login.php');
    exit;
}