<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Вход</h1>
    <form method="POST" action="login.php">
        <input name="login" placeholder="Логин" required value="qwerty" />
        <input name="password" placeholder="Пароль" type="password" required value="qwerty" />
        <button>Войти</button>
    </form>
    <?php
    require '../boot.php';
    flash();
    ?>
    <p>Еще нет аккаунта? <a href="/registration">Зарегистрироваться</a></p>
</body>

</html>