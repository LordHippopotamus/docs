<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
</head>

<body>
    <h1>Регистрация</h1>
    <form method="POST" action="register.php">
        <input name="login" placeholder="Логин" required value="qwerty" />
        <input name="password" placeholder="Пароль" type="password" required value="qwerty" />
        <input name="full_name" placeholder="Ф.И.О." required value="John Smith" />
        <input name="phone" placeholder="Телефон" required value="88005553535" />
        <input name="email" placeholder="Email" type="email" required value="qwerty@mail.com" />
        <button>Зарегистрироваться</button>
    </form>
    <?php
    require '../boot.php';
    flash('');
    ?>
    <p>Уже есть аккаунт? <a href="/login">Войти</a></p>
</body>

</html>