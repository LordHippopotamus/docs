<?php
// Подключение к базе данных
$servername = "MySQL-8.0";
$username = "root";
$password = "";
$dbname = "registration";

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Получение данных из формы
$user = $_POST['username'];
$email = $_POST['email'];
$pass = $_POST['password'];

// Валидация данных
if (empty($user) || empty($email) || empty($pass)) {
    echo "Все поля обязательны для заполнения.";
    exit();
}

// Хеширование пароля
$hashed_password = password_hash($pass, PASSWORD_DEFAULT);

// Подготовка и выполнение SQL-запроса
$sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $user, $email, $hashed_password);

if ($stmt->execute()) {
    echo "Регистрация успешна!";
} else {
    echo "Ошибка: " . $stmt->error;
}

// Закрытие подключения
$stmt->close();
$conn->close();
?>