<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Нарушениям.НЕТ-регистрация</title>
</head>
<?php

?>
<body>
    <form action="regist.php" method="post">
        <input placeholder="логин" name="login" required type="text">
        <input placeholder="пароль" name="pass" required type="password">
        <input placeholder="ФИО" name="fio" required type="text">
        <input placeholder="телефон" name="number" required type="number">
        <input placeholder="почта" name="email" required type="email">
        <button>Регистрация</button>
    </form>
</body>
</html>