<?php
session_start();
include 'db_conn.php';
$logind=$_POST['login'];
$passd=$_POST['pass'];
$adm1='coop';
$adm2='password';
$sql = "SELECT users.* FROM users 
WHERE login = :logind AND pass = :passd";
$stmt = $dbh->prepare($sql);
$stmt->execute(['logind' => $logind, 'passd' => $passd]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);
$_SESSION["user"] = [
    "id" => $data['id'],
    "fio" =>$data['fio']
];

// print_r($data);
if ($data['login'] == $logind && $data['pass'] == $passd) {
    if ($data['login'] == $adm1 && $data['pass'] == $adm2) {
        header("Location: panelAdm.php");
    }else{
        header("Location: panelUser.php");
    }
}else{
    $_SESSION['message']='Неверный логин или пароль';
    header("Location: login.php");
}