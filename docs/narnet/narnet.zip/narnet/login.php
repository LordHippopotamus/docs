<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Нарушениям.НЕТ-авторизация</title>
</head>
<body>
    
    <form action="login_db.php" method="post">
        <input placeholder="логин" name="login" required type="text">
        <input placeholder="пароль" name="pass" required type="password">
        <button>Авторизация</button>
    </form>
    <?php
    session_start();
    echo $_SESSION['message'];
    ?>
</body>
</html>