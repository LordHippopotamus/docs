-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 19 2024 г., 21:08
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `narnet`
--

-- --------------------------------------------------------

--
-- Структура таблицы `naruhtable`
--

CREATE TABLE `naruhtable` (
  `id_nar` int NOT NULL,
  `number` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `naruh` text COLLATE utf8mb4_general_ci NOT NULL,
  `fio` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `id` int NOT NULL,
  `stat` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Не просмотрено'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `naruhtable`
--

INSERT INTO `naruhtable` (`id_nar`, `number`, `naruh`, `fio`, `id`, `stat`) VALUES
(1, '12345', 'сломался', '', 5, 'Не просмотрено'),
(2, '12345678', 'умер', '', 5, 'Не Одобрено'),
(3, '12345', 'гллшгл', '', 5, 'Одобрено'),
(4, 'ukuik', 'kuiki', 'Иван Анатольевич Федорович', 1, 'Не Одобрено'),
(5, 'ukuik', 'o,i,ioo,', 'ffrfrf', 8, 'Не просмотрено'),
(6, ',io,o,', ',oi,', 'Иван Анатольевич Федорович', 1, 'Не просмотрено');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `login` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fio` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pass`, `fio`, `number`, `email`) VALUES
(1, 'log1', '123', 'Иван Анатольевич Федорович', '798810534112', 'Walion74@yandex.ru'),
(5, 'coop', 'password', '', '', ''),
(6, 'log1', '123', 'Иван Анатольевич Федорович', '798810534112', 'Walion74@yandex.ru'),
(7, 'log2', '123', 'Иван Анатольевич Федорович', '798810534112', 'Walion74@yandex.ru'),
(8, 'log4', '123', 'ffrfrf', '7988103412', '333333@gail.com');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `naruhtable`
--
ALTER TABLE `naruhtable`
  ADD PRIMARY KEY (`id_nar`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `naruhtable`
--
ALTER TABLE `naruhtable`
  MODIFY `id_nar` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
