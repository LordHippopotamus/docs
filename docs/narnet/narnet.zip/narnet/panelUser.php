<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Оставить заявку</title>
</head>
<?php
session_start();
if (!$_SESSION["user"]) {
    header("Location: login.php ");
  }
?>
<body>
    <a href="logout.php">Выход</a>
    <?php
    include 'db_conn.php';
    $id=$_SESSION['user']['id'];
    $sql = "SELECT naruhtable.* FROM naruhtable 
    WHERE id = :id";
    $stmt = $dbh->prepare($sql);
    $stmt->execute(['id' => $id]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>
    <table >
       <thead>
         <tr>
            
           <th>Номер автомобиля</th>
           <th>текст</th>
           <th>Статус</th>
         </tr>
       </thead>
       <tbody>
    <?php
    if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
    { ?>
         <tr>
            <td><?= $row["number"] ?></td>
            <td><?= $row["naruh"] ?></td>
            <td><?= $row["stat"] ?></td>
        </tr>
   <?php }}?>
    </tbody>
   </table>
    <br>
    <br>
    <form method="post">
        <input placeholder="номер автомобиля" name="number" required type="text">
        <textarea placeholder="описание" name="naruh" required type="text"></textarea>
        <button>Отправить</button>
    </form>
    <?php
    $number=$_POST['number'];
    $nar=$_POST['naruh'];
    $fio=$_SESSION['user']['fio'];
    
 
    if (isset($number) && isset($nar)) {
        try { 
            $stmt = $dbh->prepare("INSERT INTO naruhtable (number, naruh, fio, id) VALUES (:number, :naruh, :fio, :id)");
            $stmt->bindParam(':number', $number);
            $stmt->bindParam(':naruh', $nar);
            $stmt->bindParam(':fio', $fio);
            $stmt->bindParam(':id', $id);
            
            $stmt->execute();
           
            header("Refresh:0");
        exit();
        }catch (PDOException $e) {
            echo "Database error: " . $e->getMessage();
        }
    } else {
        
    }
    ?>
</body>
</html>