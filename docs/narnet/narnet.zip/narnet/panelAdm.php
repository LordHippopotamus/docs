<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Оставить заявку</title>
</head>
<?php
session_start();
if (!$_SESSION["user"]) {
    header("Location: panelAdm.php ");
  }
?>
<body>
    <a href="logout.php">Выход</a>
    <?php
    include 'db_conn.php';
    $sql = "SELECT naruhtable.* FROM naruhtable";
    $stmt = $dbh->prepare($sql);
    $stmt->execute();
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>
    <table >
       <thead>
         <tr>
         <th>Имя наршуителя</th>
           <th>Номер автомобиля</th>
           <th>текст</th>
           <th>Статус</th>
           <th>Смена Ст</th>
           <th>Выполнение</th>
         </tr>
       </thead>
       <tbody>
    <?php
    if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
    { ?>
         <tr> 
            <form method="post">
            <input name="id" value ="<?= $row["id"] ?>" hidden type="text">
            <input name="id_nar" value ="<?= $row["id_nar"] ?>" hidden type="text">
            <td><?= $row["fio"] ?></td>
            <td><?= $row["number"] ?></td>
            <td><?= $row["naruh"] ?></td>
            <td><?= $row["stat"] ?></td>
            <td>
            <select name="sel">
                <option value="Одобрено">Одобрено</option>
                <option value="Не Одобрено">Не одобрено</option>
            </select></td>
            <td><button name="update" type="submit">Обновить</button></td>
        </form>
    </tr>
   <?php }}?>
    </tbody>
   </table>
    <br>
    <br>
<?php
if (isset($_POST["update"])) {
     $id1=$_POST['id'];
 $sel=$_POST['sel'];
 $id2=$_POST['id_nar'];
 try { 
    $stmt = $dbh->prepare("UPDATE naruhtable SET stat = :sel WHERE id = :id && id_nar = :id_nar");
    $stmt->bindParam(':sel', $sel);
    $stmt->bindParam(':id', $id1);
    $stmt->bindParam(':id_nar', $id2);

    $stmt->execute();
   
    header("Refresh:0");
exit();
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
} 
}

?>
    
</body>
</html>