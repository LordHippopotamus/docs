<?php
session_start();
$logind = $_POST['login'];
$passd = $_POST['pass'];
$fiod = $_POST['fio'];
$numberd = $_POST['number'];
$emaild = $_POST['email'];
echo $logind;
echo $passd;
echo $fiod;
echo $numberd;
echo $emaild;

include 'db_conn.php';

if (isset($logind) && isset($passd) && isset($fiod) && isset($numberd) && isset($emaild)) {
    try {
        $stmt_check = $dbh->prepare("SELECT * FROM users WHERE login = :login");
        $stmt_check->bindParam(':login', $logind);
        $stmt_check->execute();
        
        if ($stmt_check->rowCount() > 0) {
            $_SESSION['message'] = 'Вы уже зарегистрированы';
            header("Location: login.php");
        } else {
            $stmt_insert = $dbh->prepare("INSERT INTO users (login, pass, fio, number, email) VALUES (:login, :pass, :fio, :number, :email)");
            $stmt_insert->bindParam(':login', $logind);
            $stmt_insert->bindParam(':pass', $passd);
            $stmt_insert->bindParam(':fio', $fiod);
            $stmt_insert->bindParam(':number', $numberd);
            $stmt_insert->bindParam(':email', $emaild);

            $stmt_insert->execute();
            $_SESSION['message'] = 'Зарегистрирован';
            header("Location: login.php");
        }

    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo 'Ошибка: не все данные были переданы';
}
