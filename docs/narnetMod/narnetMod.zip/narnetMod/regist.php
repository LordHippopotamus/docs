<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Платформа - Регистрация</title>
</head>
<?php
session_start();
if ($_SESSION["user"]) {
    header("Location: login.php ");
  }
?>
<body>
    <form action="./Rout/reg.php" method="post">
        <input placeholder="логин" name="login" required type="text">
        <input placeholder="пароль" name="pass" required type="password">
        <input placeholder="ФИО" name="fio" required type="text">
        <input placeholder="телефон" name="number" required type="text">
        <input placeholder="почта" name="email" required type="email">
        <button>Регистрация</button>
    </form>

    <a href="login.php">У вас есть уже аккаунт?</a>
</body>
</html>