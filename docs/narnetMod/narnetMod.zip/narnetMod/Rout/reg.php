<?php
session_start();
$logind = $_POST['login'];
$passd = $_POST['pass'];
$fiod = $_POST['fio'];
$numberd = $_POST['number'];
$emaild = $_POST['email'];

include 'conndb.php';

if (isset($logind) && isset($passd) && isset($fiod) && isset($numberd) && isset($emaild)) {
    try {
        $stmt_check = $dbh->prepare("SELECT * FROM users WHERE login = :login");
        $stmt_check->bindParam(':login', $logind);
        $stmt_check->execute();
        
        if ($stmt_check->rowCount() > 0) {
            $_SESSION['message'] = 'Вы уже зарегистрированы';
            header("Location: login.php");
        } else {
            // Хеширование пароля
            $hashed_password = password_hash($passd, PASSWORD_DEFAULT);

            $stmt_insert = $dbh->prepare("INSERT INTO users (login, pass, fio, number, email) VALUES (:login, :pass, :fio, :number, :email)");
            $stmt_insert->bindParam(':login', $logind);
            $stmt_insert->bindParam(':pass', $hashed_password);
            $stmt_insert->bindParam(':fio', $fiod);
            $stmt_insert->bindParam(':number', $numberd);
            $stmt_insert->bindParam(':email', $emaild);

            $stmt_insert->execute();
            
            $_SESSION['message'] = '<br><p style="background-color: green;">Пользователь зарегистрирован</p>';
            header("Location: ../login.php");
        }

    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo 'Ошибка: не все данные были переданы';
}