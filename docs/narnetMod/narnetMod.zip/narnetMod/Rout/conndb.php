<?php
$user='root';
$pass='';

try {
    $dbh = new PDO('mysql:host=localhost;dbname=narnetMod', $user, $pass);
} catch (PDOException $e) {
    echo "Ошибка подключения к базе данных: " . $e->getMessage();
    die();
}