<?php
session_start();
include 'conndb.php';
$role='admin';
$logind=$_POST['login'];
$passd=$_POST['pass'];
$sql = "SELECT users.* FROM users WHERE login = :logind";
$stmt = $dbh->prepare($sql);
$stmt->execute(['logind' => $logind]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);
$_SESSION["user"] = [
    "id" => $data['id'],
    "fio" =>$data['fio']
];

// print_r($data);
if ($data['login'] == $logind && password_verify($passd, $data['pass'])) {
    unset($_SESSION['message']);

    if ($data['role'] == $role) {
        header("Location: ../adminPanel.php");
    }else{
        header("Location: ../index.php");
    }
}else{
    unset($_SESSION['user']);
    $_SESSION['message']='<br><p style="background-color: red;">Неверный логин или пароль</p>';
    header("Location: ../login.php");
}