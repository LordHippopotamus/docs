-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 19 2024 г., 21:08
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `narnetMod`
--

-- --------------------------------------------------------

--
-- Структура таблицы `naruhtable`
--

CREATE TABLE `naruhtable` (
  `id_nar` int NOT NULL,
  `number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `naruh` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id` int NOT NULL,
  `stat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Не просмотрено'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `naruhtable`
--

INSERT INTO `naruhtable` (`id_nar`, `number`, `naruh`, `fio`, `id`, `stat`) VALUES
(7, '12345', 'колесо\r\n', 'Иван Анатольевич Федорович', 11, 'Не просмотрено'),
(8, '12345', 'екрекр', 'Иван Анатольевич Федорович', 11, 'Не Одобрено'),
(9, '12345', 'колесо', 'Иван Анатольевич Федорович', 11, 'Одобрено'),
(10, '12345', '5ннннн', 'Иван Анатольевич Федорович', 11, 'Не Одобрено'),
(11, '12345', '1233', 'Иван Анатольевич Федорович', 11, 'Не Одобрено'),
(12, '12345', 'hghтест', 'Анна Викторовна Кудзо', 16, 'Не Одобрено'),
(13, '12345', 'тест', 'Анна Викторовна Кудзо', 16, 'Не Одобрено'),
(14, '12345', 'ннн', 'Анна Викторовна Кудзо', 16, 'Не Одобрено'),
(15, '12345', 'рро', 'Иван Анатольевич Федорович', 11, 'Не просмотрено'),
(16, '0987654321', 'сдох', 'Анна Викторовна Кудзо', 17, 'Не просмотрено'),
(17, '0987654321', 'сдох', 'Анна Викторовна Кудзо', 17, 'Не Одобрено'),
(18, '12345', 'лох', 'Анна Викторовна Кудзо', 17, 'Не Одобрено'),
(19, '12345', 'шшлош\r\n', 'Анна Викторовна Кудзо', 17, 'Не просмотрено'),
(20, '12345', '12343', 'Иван Анатольевич Федорович', 11, 'Не просмотрено'),
(21, '1223', '44445', 'Иван Анатольевич Федорович', 11, 'Не просмотрено'),
(22, '12345', 'tthrrt6hrt', 'Иван Анатольевич Федорович', 21, 'Не просмотрено'),
(23, '12345', 'hhhh', 'Иван Анатольевич Федорович', 21, 'Не просмотрено'),
(24, '12345', 'ikikiki', 'Иван Анатольевич Федорович', 21, 'Не просмотрено'),
(25, '12345', 'gtg', 'Иван Анатольевич Федорович', 21, 'Не Одобрено');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `login` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fio` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pass`, `fio`, `number`, `email`, `role`) VALUES
(21, 'log9', '$2y$10$x8AsUk.gRaRmbAS4qTNP..43/GxydNsAOR/NyJHckeaeyOBZnCX3m', 'Иван Анатольевич Федорович', '+798810534112', 'Walion74@yandex.ru', 'user'),
(22, 'coop', '$2y$10$E.Lkvjfu/Tq9OIfhOsZTben6mXJAb5WTiS2CfTPTYXoAJ1uqvReoO', 'Admin', '+798810534112', 'Admin@yandex.ru', 'admin');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `naruhtable`
--
ALTER TABLE `naruhtable`
  ADD PRIMARY KEY (`id_nar`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `naruhtable`
--
ALTER TABLE `naruhtable`
  MODIFY `id_nar` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
