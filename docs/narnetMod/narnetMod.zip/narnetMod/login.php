<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Платформа - Авторизация</title>
</head>
<body>

<?php
session_start();
if ($_SESSION["user"]) {
    header("Location: index.php ");
  }
?>
    <form action="./Rout/log.php" method="post">
        <input placeholder="логин" name="login" required type="text">
        <input placeholder="пароль" name="pass" required type="password">
        <button>Авторизация</button>
    </form>
    <a href="regist.php">Вы еще не регистрировались?</a>
    <?php
    session_start();
    echo $_SESSION['message'];
    ?>
</body>
</html>